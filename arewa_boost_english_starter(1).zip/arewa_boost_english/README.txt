AREWA BOOST — ENGLISH STARTER PACKAGE

WHAT IS INCLUDED
- index.html: responsive English-language frontend.
- supabase_schema.sql: starter database schema and row-level security policies.
- This README: setup notes.

TRY IT LOCALLY
1. Extract the ZIP file.
2. Open index.html in a modern browser.
3. Add a campaign name, select the Facebook content type, paste a Facebook URL, and save.
4. In demo mode, campaign data is stored in that browser only. It is not a real online service.

TO ENABLE REAL EMAIL ACCOUNTS AND DATABASE
1. Create a project at https://supabase.com/
2. Open SQL Editor and run supabase_schema.sql. Review and test the SQL first.
3. In Supabase Project Settings / API, copy the Project URL and anon/public key.
4. In index.html, replace the empty SUPABASE_URL and SUPABASE_ANON_KEY values in CONFIG.
5. Configure authentication email settings in Supabase and test with a non-sensitive test account.
6. Deploy the static files to a host such as GitHub Pages, Netlify, or Cloudflare Pages.

SECURITY AND LIMITATIONS
- This starter is not yet a fully production-ready service. The SQL policies should be reviewed and tested before launch.
- Never put a Supabase service_role key in frontend code.
- Do not collect Facebook passwords or session cookies.
- The current frontend includes basic email auth wiring and campaign database wiring when configured, but needs testing and hardening.
- A secure admin dashboard, points award/redeem functions, email verification, rate limiting, abuse prevention, privacy policy, terms, backups, monitoring, and moderation are still needed before public launch.
- The website does not automatically deliver likes, followers, or video views. It does not use bots or fake engagement.
- For official paid promotion, use Meta Business Suite or Ads Manager: https://www.facebook.com/business/tools/meta-business-suite
- Free organic growth can be supported with content planning, analytics, and community engagement, but exact results cannot be guaranteed.

FREE HOSTING
Free tiers and availability can change. You will need to create and manage the hosting account yourself; this package does not publish itself online.
