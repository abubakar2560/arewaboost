-- Arewa Boost starter schema for Supabase
-- Run in Supabase Dashboard > SQL Editor. Review and test before production.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  points integer not null default 0 check (points >= 0),
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.campaigns (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 90),
  content_type text not null,
  goal text not null,
  url text not null,
  notes text,
  status text not null default 'Draft' check (status in ('Draft','Review','Approved','Archived')),
  created_at timestamptz not null default now()
);

create table if not exists public.points_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  amount integer not null check (amount <> 0),
  reason text not null,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.campaigns enable row level security;
alter table public.points_ledger enable row level security;

-- Users can read and update only their own profile, but cannot promote themselves to admin
create policy "Read own profile" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "Update own display name" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "Read own campaigns" on public.campaigns for select to authenticated using (auth.uid() = user_id);
create policy "Insert own campaigns" on public.campaigns for insert to authenticated with check (auth.uid() = user_id);
create policy "Update own campaigns" on public.campaigns for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Delete own campaigns" on public.campaigns for delete to authenticated using (auth.uid() = user_id);
create policy "Read own points ledger" on public.points_ledger for select to authenticated using (auth.uid() = user_id);

-- Create a profile when a new auth user signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name',''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- IMPORTANT:
-- This schema is a starter, not a fully audited production deployment.
-- Do not expose Supabase service_role keys in browser code.
-- Award/revoke points only through trusted server-side functions after validation.
-- Add admin policies and audit logging before launching an admin dashboard.
